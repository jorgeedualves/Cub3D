#include <errno.h>
#include <stdlib.h>
#include <png.h>

int main(int argc, char const *argv[]) {
    if (argc != 2)
        return 1;
    FILE    *pngFile = fopen(argv[1], "r");
    char    sig[8];

    if (!pngFile)
        return errno;
    fread(sig, 1, 8, pngFile);
    if (!png_check_sig(pngFile, 8))
        return 2;
    // png_struct *png = ;
    return 0;
}
