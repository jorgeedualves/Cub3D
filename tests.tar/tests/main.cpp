// #include <iostream>
// #include <cmath>
// #include <limits>
// #include <stdint.h>
// #include <unistd.h>

int main(void) {
    float   a = 0;
    int     b = 0;
    return (b);
}

// int main(void) {
//     int       *a = new int;
//     *a = 48 | (52 << 8) | (126 << 16) | (32 << 24);

//     uintptr_t   reinterpretPointer = (uintptr_t)a;

//     char    *ptr = reinterpret_cast<char *>(reinterpretPointer);
//     std::cout << *a << '\n';
//     for (int i = 0; i < 4; i++) {
//         std::cout << ptr[i];
//     }
//     delete a;
//     return 0;
// }

// int main(void) {
//     float       *a = new float;
//     *a = 15;
//     int *p = reinterpret_cast<int *>(a);
//     char        ch[2] = {'\0', ' '};

//     std::cout << a << '\n';
//     int nb = 1;
//     int bit = 1 << 31;
//     std::cout << "nb to print in binary: " << nb << '\n';
//     for (int i = 31; i >= 0; i--) {
//         // std::cout << "Comparing " << bit << " bit" << '\n';
//         std::cout << (nb & bit) << ch[!(i % 8)];
//         bit >>= 1;
//     }
//     for (int i = 31; i >= 0; i--)
//         std::cout << ((nb >> i) & 1);
//     std::cout << '\n';
//     for (int i = 31; i >= 0; i--)
//         std::cout << ((*p >> i) & 1);

//     std::cout << '\n';
//     delete a;
//     return (0);
// }

// void    f1(int i) {
//     std::cout << &i << '\n';
//     f1(i);
// }

// int main(void) {
//     // f1(10);
//     int     i;
//     int     *p = new int;
//     std::cout << &i << '\n';
//     std::cout << p << '\n';
//     delete p;
//     return (0);
// }

